Paho Java ME client for MQTT

The Java ME client requires the Oracle J2ME SDK 3.2 (which is only available for windows) and assumes it will be installed in c:/Java_ME_platform_SDK_3.2/

The client jar is built using ant and the build.xml file in org.eclipse.paho.jmeclient.mqttv3/
